package dk.sdu.ISU.uno;

public interface Descriptable {
    String getDescription();
}
