package dk.sdu.ISU.uno.cards;

public enum Color {
    WILD,
    RED,
    BLUE,
    GREEN,
    YELLOW
}
